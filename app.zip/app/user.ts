export class User{
    constructor(
        name:string,
        email:string,
        password:string,
        url:string
    ){}
}